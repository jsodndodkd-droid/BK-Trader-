import { useState, useEffect, useRef, useCallback } from "react";

const TD_KEY = "68b4cea571f84fae8033b2da341eb177";
const AV_KEY = "K611Z3WVPKSQN93G";
const AV_LIMIT = 25;

function getTodayKey(){const d=new Date();return"bkav_"+d.getUTCFullYear()+"_"+d.getUTCMonth()+"_"+d.getUTCDate();}
function getAvUsed(){try{return parseInt(sessionStorage.getItem(getTodayKey())||"0");}catch(e){return 0;}}
function incAvUsed(){try{const k=getTodayKey(),c=getAvUsed();sessionStorage.setItem(k,String(c+1));}catch(e){}}
function getAvLeft(){return Math.max(0,AV_LIMIT-getAvUsed());}
function isWeekend(){const d=new Date().getUTCDay();return d===0||d===6;}

async function fetchPrice(pair){
  try{const[b,q]=pair.split("/");const r=await fetch("https://open.er-api.com/v6/latest/"+b);if(r.ok){const d=await r.json();if(d.rates&&d.rates[q])return d.rates[q];}}catch(e){}
  return null;
}

async function fetchCandles(pair,tf){
  const iv={"5s":"1min","10s":"1min","30s":"1min","1m":"1min","2m":"2min","5m":"5min","30m":"30min"}[tf]||"1min";
  if(getAvLeft()>0&&!isWeekend()){
    try{
      const aiv={"5s":"1min","10s":"1min","30s":"1min","1m":"1min","2m":"5min","5m":"5min","30m":"30min"}[tf]||"1min";
      const[fs,ts]=pair.split("/");
      const r=await fetch("https://www.alphavantage.co/query?function=FX_INTRADAY&from_symbol="+fs+"&to_symbol="+ts+"&interval="+aiv+"&outputsize=compact&apikey="+AV_KEY);
      if(r.ok){const d=await r.json();const key="Time Series FX ("+aiv+")";
        if(d[key]){incAvUsed();const c=Object.entries(d[key]).sort((a,b)=>new Date(a[0])-new Date(b[0])).map(([,v])=>({open:parseFloat(v["1. open"]),high:parseFloat(v["2. high"]),low:parseFloat(v["3. low"]),close:parseFloat(v["4. close"])}));
          if(c.length>=20)return{candles:c,src:"REAL"};}}
    }catch(e){}
  }
  try{const r=await fetch("https://api.twelvedata.com/time_series?symbol="+pair+"&interval="+iv+"&outputsize=80&apikey="+TD_KEY);if(r.ok){const d=await r.json();if(d.values&&d.values.length>=20)return{candles:d.values.reverse().map(v=>({open:+v.open,high:+v.high,low:+v.low,close:+v.close})),src:"REAL"};}}catch(e){}
  return{candles:makeSmart(150,null,pair),src:"SMART"};
}

function makeSmart(n,anchor,pair){
  const isJPY=pair.includes("JPY"),vol=isJPY?0.07:0.0007;
  const out=[];let p=anchor||(isJPY?145:1.1);
  for(let i=0;i<n;i++){const chg=(Math.random()-0.49)*vol+Math.sin(i/10)*vol*0.3,o=p,c=p+chg,sp=vol*0.3;out.push({open:o,high:Math.max(o,c)+Math.random()*sp,low:Math.min(o,c)-Math.random()*sp,close:c});p=c;}
  if(anchor)out[out.length-1].close=anchor;
  return out;
}

function ema(a,p){if(a.length<p)return null;const k=2/(p+1);let e=a.slice(0,p).reduce((x,y)=>x+y,0)/p;for(let i=p;i<a.length;i++)e=a[i]*k+e*(1-k);return e;}
function rsi(a,p=14){if(a.length<p+1)return null;let g=0,l=0;for(let i=a.length-p;i<a.length;i++){const d=a[i]-a[i-1];d>0?g+=d:l+=Math.abs(d);}return 100-100/(1+(g/p)/((l/p)||0.0001));}
function macd(a){if(a.length<26)return null;const m12=ema(a,12),m26=ema(a,26);if(!m12||!m26)return null;const line=m12-m26,h=[];for(let i=9;i<=a.length;i++){const e12=ema(a.slice(0,i),12),e26=ema(a.slice(0,i),26);if(e12&&e26)h.push(e12-e26);}const sig=h.length>=9?ema(h.slice(-9),9):null;return{line,sig,hist:sig!=null?line-sig:null};}
function stoch(H,L,C,p=14){if(C.length<p)return null;const hh=Math.max(...H.slice(-p)),ll=Math.min(...L.slice(-p));return hh===ll?50:((C[C.length-1]-ll)/(hh-ll))*100;}
function bb(a,p=20,sd=2){if(a.length<p)return null;const sl=a.slice(-p),m=sl.reduce((x,y)=>x+y,0)/p,std=Math.sqrt(sl.reduce((x,y)=>x+(y-m)**2,0)/p);return{upper:m+sd*std,mid:m,lower:m-sd*std};}
function atr(H,L,C,p=14){if(C.length<p+1)return null;const t=[];for(let i=1;i<C.length;i++)t.push(Math.max(H[i]-L[i],Math.abs(H[i]-C[i-1]),Math.abs(L[i]-C[i-1])));return t.slice(-p).reduce((x,y)=>x+y,0)/p;}
function wr(H,L,C,p=14){if(C.length<p)return null;const hh=Math.max(...H.slice(-p)),ll=Math.min(...L.slice(-p));return hh===ll?-50:((hh-C[C.length-1])/(hh-ll))*-100;}

function signal(candles,tf){
  if(candles.length<20)return null;
  const C=candles.map(c=>c.close),H=candles.map(c=>c.high),L=candles.map(c=>c.low);
  let bull=0,bear=0;const tags=[],reasons=[];
  const lc=C[C.length-1],pc=C[C.length-2];
  const e8=ema(C,8),e21=ema(C,21),e50=ema(C,50);
  if(e8&&e21){if(e8>e21){bull+=2;tags.push("EMA ↑");}else{bear+=2;tags.push("EMA ↓");}}
  if(e21&&e50){e21>e50?bull+=1:bear+=1;}
  const rv=rsi(C);
  if(rv!=null){if(rv<30){bull+=3;tags.push("RSI OS ↑");reasons.push("RSI "+rv.toFixed(0)+" oversold");}else if(rv<45){bull+=1;tags.push("RSI Low ↑");}else if(rv>70){bear+=3;tags.push("RSI OB ↓");reasons.push("RSI "+rv.toFixed(0)+" overbought");}else if(rv>55){bear+=1;tags.push("RSI Hi ↓");}else{rv>50?bull+=0.5:bear+=0.5;}}
  const mv=macd(C);
  if(mv&&mv.hist!=null){if(mv.hist>0){bull+=2;tags.push("MACD ↑");}else{bear+=2;tags.push("MACD ↓");}const pm=macd(C.slice(0,-2));if(pm&&pm.hist!=null){if(mv.hist>0&&pm.hist<0){bull+=2;tags.push("MACD X ↑");reasons.push("MACD crossover up");}else if(mv.hist<0&&pm.hist>0){bear+=2;tags.push("MACD X ↓");reasons.push("MACD crossover down");}}}
  const bv=bb(C);
  if(bv){if(lc<bv.lower){bull+=3;tags.push("BB OS ↑");reasons.push("Below lower BB");}else if(lc>bv.upper){bear+=3;tags.push("BB OB ↓");reasons.push("Above upper BB");}else if(lc>bv.mid&&pc<=bv.mid){bull+=1.5;tags.push("BB Mid ↑");}else if(lc<bv.mid&&pc>=bv.mid){bear+=1.5;tags.push("BB Mid ↓");}else{lc>bv.mid?bull+=0.5:bear+=0.5;}}
  const sv=stoch(H,L,C);
  if(sv!=null){if(sv<20){bull+=2.5;tags.push("Stoch OS ↑");reasons.push("Stoch "+sv.toFixed(0)+" oversold");}else if(sv<35){bull+=1;tags.push("Stoch Lo ↑");}else if(sv>80){bear+=2.5;tags.push("Stoch OB ↓");reasons.push("Stoch "+sv.toFixed(0)+" overbought");}else if(sv>65){bear+=1;tags.push("Stoch Hi ↓");}else{sv>50?bull+=0.3:bear+=0.3;}}
  const wv=wr(H,L,C);if(wv!=null){if(wv<-80){bull+=1.5;tags.push("W%R OS ↑");}else if(wv>-20){bear+=1.5;tags.push("W%R OB ↓");}else{wv>-50?bear+=0.3:bull+=0.3;}}
  const l3=candles.slice(-3),bC=l3.filter(c=>c.close>c.open).length,brC=l3.filter(c=>c.close<c.open).length;
  if(bC>=2){bull+=1;tags.push("PA ↑");}else if(brC>=2){bear+=1;tags.push("PA ↓");}
  if(["5s","10s","30s"].includes(tf)&&C.length>=6){const vel=((lc-C[C.length-6])/C[C.length-6])*10000;if(vel>1){bull+=1.5;tags.push("Vel ↑");}else if(vel<-1){bear+=1.5;tags.push("Vel ↓");}}
  const at=atr(H,L,C),ac=C.slice(-20).reduce((x,y)=>x+y,0)/20,vp=at?(at/ac)*100:0;
  const vol=vp>0.1?"High":vp>0.05?"Medium":"Low";
  const total=bull+bear;if(total===0)return null;
  const dir=bull>=bear?"CALL":"PUT",raw=Math.max(bull,bear)/total,conf=Math.min(96,Math.round(60+raw*36));
  const str=conf>=85?"Very Strong":conf>=76?"Strong":conf>=68?"Moderate":"Fair";
  return{direction:dir,confidence:conf,strength:str,tags:tags.slice(0,9),reasons,vol,bull:Math.round(bull*10)/10,bear:Math.round(bear*10)/10};
}

const ALL_NEWS=[
  {days:[1,2,3,4,5],hour:0, min:0, dur:30,name:"Asian Open",      pkt:"5:00 AM", pairs:["USD/JPY","AUD/USD","NZD/USD","AUD/JPY"]},
  {days:[1,2,3,4,5],hour:1, min:30,dur:30,name:"Japan Data",      pkt:"6:30 AM", pairs:["USD/JPY","EUR/JPY","GBP/JPY","AUD/JPY"]},
  {days:[1,2,3,4,5],hour:3, min:30,dur:30,name:"AUS/NZ Data",     pkt:"8:30 AM", pairs:["AUD/USD","NZD/USD","AUD/JPY","AUD/NZD"]},
  {days:[1,2,3,4,5],hour:7, min:0, dur:45,name:"London Open",     pkt:"12:00 PM",pairs:["EUR/USD","GBP/USD","EUR/GBP","GBP/JPY"]},
  {days:[1,2,3,4,5],hour:8, min:30,dur:30,name:"EUR Data",        pkt:"1:30 PM", pairs:["EUR/USD","EUR/GBP","EUR/JPY","EUR/AUD"]},
  {days:[1,2,3,4,5],hour:10,min:0, dur:30,name:"UK Data",         pkt:"3:00 PM", pairs:["GBP/USD","EUR/GBP","GBP/JPY","GBP/AUD"]},
  {days:[1,2,3,4,5],hour:12,min:30,dur:30,name:"US Pre-Market",   pkt:"5:30 PM", pairs:["EUR/USD","GBP/USD","USD/JPY","USD/CAD"]},
  {days:[1,2,3,4,5],hour:13,min:0, dur:45,name:"NY Open",         pkt:"6:00 PM", pairs:["EUR/USD","GBP/USD","USD/JPY","USD/CAD","USD/CHF"]},
  {days:[1,2,3,4,5],hour:13,min:30,dur:60,name:"US Economic Data",pkt:"6:30 PM", pairs:["EUR/USD","GBP/USD","USD/JPY","USD/CAD","AUD/USD","NZD/USD"]},
  {days:[1,2,3,4,5],hour:14,min:0, dur:30,name:"US CPI/Jobs",     pkt:"7:00 PM", pairs:["EUR/USD","GBP/USD","USD/JPY","USD/CAD"]},
  {days:[1,2,3,4,5],hour:14,min:30,dur:30,name:"Fed News",        pkt:"7:30 PM", pairs:["EUR/USD","GBP/USD","USD/JPY","USD/CHF"]},
  {days:[1,2,3,4,5],hour:18,min:0, dur:30,name:"NY Close",        pkt:"11:00 PM",pairs:["EUR/USD","GBP/USD","USD/JPY"]},
  {days:[5],         hour:13,min:25,dur:90,name:"NFP — AVOID ALL", pkt:"6:25 PM", pairs:["EUR/USD","GBP/USD","USD/JPY","USD/CAD","AUD/USD","NZD/USD","USD/CHF","EUR/JPY","GBP/JPY"]},
];
function checkNews(pair){
  const now=new Date(),ud=now.getUTCDay(),um=now.getUTCHours()*60+now.getUTCMinutes();
  for(const ev of ALL_NEWS){if(!ev.days.includes(ud))continue;const s=ev.hour*60+ev.min,e=s+ev.dur;if(um>=s-5&&um<=e){const hit=ev.name.includes("NFP")||ev.pairs.includes(pair)||ev.pairs.some(p=>p.includes(pair.split("/")[0])||p.includes(pair.split("/")[1]));if(hit)return{risk:true,name:ev.name,left:Math.max(0,e-um),pkt:ev.pkt};}}
  return{risk:false};
}
function getUpcomingNews(){
  const now=new Date(),ud=now.getUTCDay(),um=now.getUTCHours()*60+now.getUTCMinutes();
  return ALL_NEWS.filter(ev=>ev.days.includes(ud)).map(ev=>({...ev,sm:ev.hour*60+ev.min})).filter(ev=>ev.sm>um).sort((a,b)=>a.sm-b.sm).slice(0,3);
}
function getSessions(){
  const t=new Date().getUTCHours()*60+new Date().getUTCMinutes();
  return[{name:"Sydney",start:21*60,end:6*60,color:"#38bdf8",ov:true},{name:"Tokyo",start:0,end:9*60,color:"#f59e0b",ov:false},{name:"London",start:7*60,end:16*60,color:"#c084fc",ov:false},{name:"New York",start:12*60,end:21*60,color:"#d4af37",ov:false}]
    .map(s=>({...s,active:s.ov?(t>=s.start||t<s.end):(t>=s.start&&t<s.end)}));
}
function calcRisk(bal,rp,pay){const t=(bal*rp)/100;return{amt:t.toFixed(2),profit:(t*(pay/100)).toFixed(2),maxLoss:(bal*0.1).toFixed(2),maxTrades:Math.floor((bal*0.1)/t)};}
function getMart(base,pay){const rows=[];let s=base,lost=0;for(let i=1;i<=6;i++){rows.push({step:i,stake:s.toFixed(2),profit:(s*(pay/100)).toFixed(2),risk:(lost+s).toFixed(2)});lost+=s;s=Math.ceil((lost/(pay/100))*10)/10;}return rows;}

function playSound(type){
  try{if(navigator.vibrate)navigator.vibrate(type==="CALL"?[80,40,80]:[160]);
    const ctx=new(window.AudioContext||window.webkitAudioContext)();const osc=ctx.createOscillator(),g=ctx.createGain();osc.connect(g);g.connect(ctx.destination);
    if(type==="CALL"){osc.frequency.setValueAtTime(440,ctx.currentTime);osc.frequency.setValueAtTime(880,ctx.currentTime+0.18);}else{osc.frequency.setValueAtTime(880,ctx.currentTime);osc.frequency.setValueAtTime(440,ctx.currentTime+0.18);}
    g.gain.setValueAtTime(0.2,ctx.currentTime);g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+0.4);osc.start();osc.stop(ctx.currentTime+0.4);
  }catch(e){}
}
function playExpiry(){
  try{if(navigator.vibrate)navigator.vibrate([40,40,40,40,40]);
    const ctx=new(window.AudioContext||window.webkitAudioContext)();
    [0,0.18,0.36].forEach(t=>{const osc=ctx.createOscillator(),g=ctx.createGain();osc.connect(g);g.connect(ctx.destination);osc.frequency.value=500;g.gain.setValueAtTime(0.18,ctx.currentTime+t);g.gain.exponentialRampToValueAtTime(0.001,ctx.currentTime+t+0.12);osc.start(ctx.currentTime+t);osc.stop(ctx.currentTime+t+0.13);});
  }catch(e){}
}

const PAIRS=["EUR/USD","GBP/USD","USD/JPY","AUD/USD","USD/CAD","EUR/GBP","EUR/JPY","GBP/JPY","NZD/USD","USD/CHF","EUR/AUD","GBP/AUD","EUR/CAD","AUD/JPY","CAD/JPY","EUR/NZD","GBP/NZD","AUD/NZD","AUD/CAD","EUR/CHF"];
const TFS=["5s","10s","30s","1m","2m","5m","30m"];
const TF_SEC={"5s":5,"10s":10,"30s":30,"1m":60,"2m":120,"5m":300,"30m":1800};

// ── GOLD THEME COLORS ──
const G = {
  gold:     "#d4af37",
  goldLt:   "#f0c040",
  goldDim:  "#a07c20",
  goldGlow: "rgba(212,175,55,",
  bg:       "#080808",
  bg2:      "#0f0f0f",
  card:     "rgba(255,255,255,0.03)",
  cardBr:   "rgba(212,175,55,0.12)",
  txt:      "#f5f0e8",
  sub:      "#6b6050",
  border:   "rgba(212,175,55,0.1)",
  green:    "#22c55e",
  red:      "#ef4444",
};

// ── BK LOGO SVG ──
function BKLogo({size=40}){
  return(
    <svg width={size} height={size} viewBox="0 0 40 40" fill="none">
      <defs>
        <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f0c040"/>
          <stop offset="50%" stopColor="#d4af37"/>
          <stop offset="100%" stopColor="#a07c20"/>
        </linearGradient>
        <linearGradient id="bgGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#1a1400"/>
          <stop offset="100%" stopColor="#0a0800"/>
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="11" fill="url(#bgGrad)"/>
      <rect width="40" height="40" rx="11" fill="none" stroke="url(#goldGrad)" strokeWidth="1.2" opacity=".6"/>
      {/* B */}
      <text x="3" y="29" fontSize="22" fontWeight="900" fontFamily="'Inter',sans-serif" fill="url(#goldGrad)" letterSpacing="-1">BK</text>
    </svg>
  );
}

// ── PIN SCREEN ──
function Pin({onUnlock}){
  const[pin,setPin]=useState(""),[ err,setErr]=useState(false),[shake,setShake]=useState(false);
  const tap=d=>{if(pin.length>=4)return;const next=pin+d;setPin(next);if(next.length===4){if(next==="2008")setTimeout(onUnlock,120);else{setErr(true);setShake(true);if(navigator.vibrate)navigator.vibrate([300]);setTimeout(()=>{setPin("");setErr(false);setShake(false);},700);}}};
  return(
    <div style={{minHeight:"100vh",background:"#080808",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Inter',sans-serif",position:"relative",overflow:"hidden"}}>
      {/* Gold ambient glow */}
      <div style={{position:"absolute",top:"20%",left:"50%",transform:"translateX(-50%)",width:300,height:300,borderRadius:"50%",background:"radial-gradient(circle,rgba(212,175,55,.06) 0%,transparent 70%)",pointerEvents:"none"}}/>
      <div style={{width:"100%",maxWidth:340,padding:"0 28px",position:"relative",zIndex:1}}>
        {/* Logo + Title */}
        <div style={{textAlign:"center",marginBottom:48}}>
          <div style={{display:"inline-block",marginBottom:20,position:"relative"}}>
            <div style={{width:80,height:80,borderRadius:22,background:"linear-gradient(135deg,#1a1200,#0a0800)",border:"1px solid rgba(212,175,55,.3)",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 0 40px rgba(212,175,55,.15), 0 0 80px rgba(212,175,55,.05)"}}>
              <svg width="52" height="52" viewBox="0 0 52 52" fill="none">
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0%" stopColor="#f0c040"/>
                    <stop offset="100%" stopColor="#a07c20"/>
                  </linearGradient>
                </defs>
                <text x="1" y="40" fontSize="36" fontWeight="900" fontFamily="'Inter',sans-serif" fill="url(#g1)">BK</text>
              </svg>
            </div>
            <div style={{position:"absolute",bottom:-2,right:-2,width:14,height:14,borderRadius:"50%",background:"#d4af37",border:"2px solid #080808",animation:"goldPulse 2s infinite"}}/>
          </div>
          <div style={{fontSize:28,fontWeight:900,letterSpacing:6,marginBottom:4,background:"linear-gradient(135deg,#f0c040,#d4af37,#a07c20)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>BK TRADER</div>
          <div style={{fontSize:9,color:G.sub,letterSpacing:5,textTransform:"uppercase"}}>Professional Signal Board</div>
        </div>
        {/* Dots */}
        <div style={{display:"flex",justifyContent:"center",gap:18,marginBottom:28,animation:shake?"shk .5s":"none"}}>
          {[0,1,2,3].map(i=>(
            <div key={i} style={{width:13,height:13,borderRadius:"50%",background:i<pin.length?(err?"#ef4444":"#d4af37"):"transparent",border:"1.5px solid "+(i<pin.length?(err?"#ef4444":"#d4af37"):"rgba(212,175,55,.2)"),transition:"all .2s",boxShadow:i<pin.length&&!err?"0 0 14px rgba(212,175,55,.5)":"none"}}/>
          ))}
        </div>
        {err&&<p style={{color:"#ef4444",fontSize:11,textAlign:"center",marginBottom:12,fontWeight:700,letterSpacing:.5}}>Wrong PIN — Try again</p>}
        {/* Keypad */}
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
          {[1,2,3,4,5,6,7,8,9].map(n=>(
            <button key={n} onClick={()=>tap(String(n))} style={{height:62,borderRadius:14,border:"1px solid rgba(212,175,55,.1)",background:"rgba(212,175,55,.04)",color:"#c8b87a",fontSize:22,fontWeight:400,cursor:"pointer",transition:"all .12s"}}>{n}</button>
          ))}
          <div/>
          <button onClick={()=>tap("0")} style={{height:62,borderRadius:14,border:"1px solid rgba(212,175,55,.1)",background:"rgba(212,175,55,.04)",color:"#c8b87a",fontSize:22,cursor:"pointer"}}>0</button>
          <button onClick={()=>setPin(p=>p.slice(0,-1))} style={{height:62,borderRadius:14,border:"1px solid rgba(212,175,55,.06)",background:"rgba(212,175,55,.02)",color:G.sub,fontSize:18,cursor:"pointer"}}>⌫</button>
        </div>
        <p style={{textAlign:"center",color:G.sub,fontSize:10,marginTop:24,letterSpacing:.5}}>🔐 Secured • BK Trader Pro</p>
      </div>
      <style>{`
        @keyframes shk{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}
        @keyframes goldPulse{0%,100%{opacity:1;box-shadow:0 0 0 0 rgba(212,175,55,.4)}50%{opacity:.8;box-shadow:0 0 0 4px rgba(212,175,55,0)}}
        button:active{transform:scale(.94)!important;background:rgba(212,175,55,.08)!important}
      `}</style>
    </div>
  );
}

// ── BOARD ──
function Board(){
  const[tab,setTab]=useState(0);
  const[pair,setPair]=useState("EUR/USD");
  const[tf,setTf]=useState("1m");
  const[sig,setSig]=useState(null);
  const[loading,setLoading]=useState(false);
  const[status,setStatus]=useState("");
  const[locked,setLocked]=useState(false);
  const[cd,setCd]=useState(null);
  const[sessions,setSessions]=useState(getSessions());
  const[price,setPrice]=useState(null);
  const[prevP,setPrevP]=useState(null);
  const[wins,setWins]=useState(0);
  const[losses,setLosses]=useState(0);
  const[total,setTotal]=useState(0);
  const[sigKey,setSigKey]=useState(0);
  const[search,setSearch]=useState("");
  const[marked,setMarked]=useState(false);
  const[src,setSrc]=useState("");
  const[showR,setShowR]=useState(false);
  const[newsRisk,setNewsRisk]=useState({risk:false});
  const[history,setHistory]=useState([]);
  const[scanRes,setScanRes]=useState([]);
  const[scanning,setScanning]=useState(false);
  const[bal,setBal]=useState("1000");
  const[rp,setRp]=useState("2");
  const[pay,setPay]=useState("80");
  const[mb,setMb]=useState("1");
  const[avLeft,setAvLeft]=useState(getAvLeft());
  const[wknd,setWknd]=useState(isWeekend());
  const[upcoming,setUpcoming]=useState(getUpcomingNews());
  const timerRef=useRef(null),expRef=useRef(false);
  const price_=price;

  const refreshPrice=useCallback(async()=>{const p=await fetchPrice(pair);if(p!=null){setPrevP(price_);setPrice(p);}},[pair,price_]);
  useEffect(()=>{setPrice(null);setPrevP(null);refreshPrice();const iv=setInterval(refreshPrice,8000);return()=>clearInterval(iv);},[pair]);
  useEffect(()=>{const iv=setInterval(()=>setSessions(getSessions()),30000);return()=>clearInterval(iv);},[]);
  useEffect(()=>{setNewsRisk(checkNews(pair));setUpcoming(getUpcomingNews());},[pair]);
  useEffect(()=>{const iv=setInterval(()=>{setNewsRisk(checkNews(pair));setUpcoming(getUpcomingNews());},60000);return()=>clearInterval(iv);},[pair]);
  useEffect(()=>{
    clearTimeout(timerRef.current);if(cd===null)return;
    if(cd<=0){if(!expRef.current){expRef.current=true;playExpiry();}return;}
    timerRef.current=setTimeout(()=>setCd(c=>c!==null?c-1:null),1000);
    return()=>clearTimeout(timerRef.current);
  },[cd]);

  const generate=async()=>{
    if(locked||loading)return;
    if(newsRisk.risk){alert("🚫 "+newsRisk.name+"\n\nSignal blocked!\nWait "+newsRisk.left+" minutes.\nPKT: "+newsRisk.pkt);return;}
    setLoading(true);setSig(null);setMarked(false);setStatus("");setShowR(false);
    setStatus("Fetching market data...");
    const result=await fetchCandles(pair,tf);
    setAvLeft(getAvLeft());setSrc(result.src);
    setStatus("Analyzing indicators...");
    await new Promise(r=>setTimeout(r,300));
    const s=signal(result.candles,tf);setStatus("");
    if(s){setSig(s);setSigKey(k=>k+1);playSound(s.direction);setLocked(true);expRef.current=false;setCd(TF_SEC[tf]);setTotal(t=>t+1);
      setHistory(h=>[{id:Date.now(),pair,tf,dir:s.direction,conf:s.confidence,str:s.strength,time:new Date().toLocaleTimeString(),res:null},...h].slice(0,20));}
    setLoading(false);
  };

  const mark=won=>{if(marked)return;setMarked(true);if(won)setWins(w=>w+1);else setLosses(l=>l+1);
    setHistory(h=>h.map((s,i)=>i===0?{...s,res:won?"WIN":"LOSS"}:s));
    setTimeout(()=>{setSig(null);setCd(null);setLocked(false);setMarked(false);},1200);};

  const doScan=async()=>{
    if(scanning)return;setScanning(true);setScanRes([]);setStatus("Scanning pairs...");
    const results=[];
    for(const p of PAIRS.slice(0,10)){const r=await fetchCandles(p,tf);setAvLeft(getAvLeft());const s=signal(r.candles,tf);if(s)results.push({pair:p,...s,src:r.src});}
    results.sort((a,b)=>b.confidence-a.confidence);setScanRes(results);setStatus("");setScanning(false);
    if(navigator.vibrate)navigator.vibrate([100]);
  };

  const fmt=s=>{if(!s||s<=0)return"0s";return s<60?s+"s":Math.floor(s/60)+"m "+String(s%60).padStart(2,"0")+"s";};
  const acc=(wins+losses)>0?Math.round((wins/(wins+losses))*100):null;
  const actS=sessions.filter(s=>s.active);
  const expired=cd!==null&&cd<=0;
  const filtP=PAIRS.filter(p=>p.toLowerCase().includes(search.toLowerCase()));
  const isJPY=pair.includes("JPY");
  const pChg=(price!=null&&prevP!=null)?price-prevP:null;
  const isCall=sig?.direction==="CALL";
  const sCol=isCall?G.green:G.red;
  const sBg=isCall?"rgba(34,197,94,.06)":"rgba(239,68,68,.06)";
  const sBr=isCall?"rgba(34,197,94,.2)":"rgba(239,68,68,.2)";
  const eCol=expired?G.red:cd!=null&&cd<=3?"#f59e0b":G.green;
  const eMsg=sig?(expired?"Signal expired — generate new":cd!=null&&cd<=3?"Too late — wait for next candle":"Enter on NEXT candle open ("+tf+")"):null;
  const pCol=pChg==null?G.sub:pChg>0?G.green:pChg<0?G.red:G.sub;
  const avCol=avLeft>10?G.gold:avLeft>0?"#f59e0b":G.red;
  const volC={"High":G.red,"Medium":"#f59e0b","Low":G.green};
  const blocked=locked||loading||newsRisk.risk;
  const rc=calcRisk(parseFloat(bal)||1000,parseFloat(rp)||2,parseFloat(pay)||80);
  const TABS=[{icon:"⚡",l:"Signal"},{icon:"🔍",l:"Scanner"},{icon:"📋",l:"History"},{icon:"💰",l:"Risk"}];

  return(
    <div style={{minHeight:"100vh",background:G.bg,fontFamily:"'Inter',sans-serif",paddingBottom:88,color:G.txt,position:"relative"}}>
      {/* Ambient glow top */}
      <div style={{position:"fixed",top:0,left:"50%",transform:"translateX(-50%)",width:"100%",height:200,background:"radial-gradient(ellipse at top,rgba(212,175,55,.04) 0%,transparent 70%)",pointerEvents:"none",zIndex:0}}/>

      {/* ── HEADER ── */}
      <div style={{background:"rgba(8,8,8,.96)",borderBottom:"1px solid rgba(212,175,55,.12)",padding:"12px 16px",backdropFilter:"blur(20px)",position:"sticky",top:0,zIndex:100}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <div style={{width:38,height:38,borderRadius:11,background:"linear-gradient(135deg,#1a1200,#0d0900)",border:"1px solid rgba(212,175,55,.25)",display:"flex",alignItems:"center",justifyContent:"center",boxShadow:"0 2px 12px rgba(212,175,55,.1)"}}>
              <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
                <defs><linearGradient id="hg" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stopColor="#f0c040"/><stop offset="100%" stopColor="#a07c20"/></linearGradient></defs>
                <text x="-1" y="22" fontSize="20" fontWeight="900" fontFamily="'Inter',sans-serif" fill="url(#hg)">BK</text>
              </svg>
            </div>
            <div>
              <div style={{fontSize:15,fontWeight:900,letterSpacing:2.5,background:"linear-gradient(135deg,#f0c040,#d4af37)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>BK TRADER</div>
              <div style={{fontSize:8,color:G.sub,letterSpacing:2,textTransform:"uppercase"}}>Signal Board Pro</div>
            </div>
          </div>
          <div style={{display:"flex",gap:5,alignItems:"center"}}>
            {acc!=null&&<div style={{padding:"3px 9px",borderRadius:20,background:"rgba(212,175,55,.08)",border:"1px solid rgba(212,175,55,.2)",fontSize:10,fontWeight:700,color:G.gold}}>{acc}% ACC</div>}
            <div style={{padding:"3px 9px",borderRadius:20,background:"rgba(212,175,55,.05)",border:"1px solid rgba(212,175,55,.15)",fontSize:10,fontWeight:700,color:avCol}}>
              {wknd?"WKD":"📡 "+avLeft+"/25"}
            </div>
            <div style={{padding:"3px 9px",borderRadius:20,background:"rgba(34,197,94,.08)",border:"1px solid rgba(34,197,94,.2)",fontSize:10,fontWeight:700,color:G.green,display:"flex",alignItems:"center",gap:4}}>
              <span style={{width:5,height:5,background:G.green,borderRadius:"50%",display:"inline-block",animation:"lv 1.8s infinite"}}/>LIVE
            </div>
          </div>
        </div>
        {/* Sessions */}
        <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
          {sessions.map(s=>(
            <div key={s.name} style={{display:"flex",alignItems:"center",gap:3,padding:"2px 8px",borderRadius:5,background:s.active?"rgba(212,175,55,.06)":"transparent",border:"1px solid "+(s.active?"rgba(212,175,55,.2)":"rgba(255,255,255,.04)")}}>
              <div style={{width:4,height:4,borderRadius:"50%",background:s.active?G.gold:G.sub}}/>
              <span style={{fontSize:9,fontWeight:600,color:s.active?G.goldLt:G.sub}}>{s.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* ALERTS */}
      {wknd&&<div style={{background:"rgba(239,68,68,.06)",borderBottom:"1px solid rgba(239,68,68,.12)",padding:"7px 16px",fontSize:11,color:"#fca5a5",fontWeight:600}}>🔴 Weekend — Market closed. Do not trade.</div>}
      {!wknd&&avLeft===0&&<div style={{background:"rgba(239,68,68,.06)",borderBottom:"1px solid rgba(239,68,68,.12)",padding:"7px 16px",fontSize:11,color:"#fca5a5",fontWeight:600}}>🔴 Daily limit (25/25) reached — Smart mode until midnight UTC</div>}
      {!wknd&&avLeft>0&&avLeft<=5&&<div style={{background:"rgba(245,158,11,.06)",borderBottom:"1px solid rgba(245,158,11,.12)",padding:"7px 16px",fontSize:11,color:"#fcd34d",fontWeight:600}}>⚠️ Only {avLeft} real requests left today</div>}
      {newsRisk.risk&&<div style={{background:"rgba(239,68,68,.08)",borderBottom:"1px solid rgba(239,68,68,.18)",padding:"7px 16px",fontSize:11,color:"#fca5a5",fontWeight:700}}>🚫 {newsRisk.name} — Signal blocked! Wait {newsRisk.left}min</div>}
      {status&&<div style={{background:"rgba(212,175,55,.04)",borderBottom:"1px solid rgba(212,175,55,.1)",padding:"7px 16px",fontSize:11,color:G.gold,fontWeight:600,display:"flex",alignItems:"center",gap:6}}><span style={{animation:"spin 1s linear infinite",display:"inline-block"}}>⚙️</span>{status}</div>}

      <div style={{padding:"14px 14px 0",position:"relative",zIndex:1}}>
        {/* TABS */}
        <div style={{display:"flex",background:"rgba(212,175,55,.03)",borderRadius:14,padding:3,marginBottom:14,border:"1px solid rgba(212,175,55,.08)"}}>
          {TABS.map((t,i)=>(
            <button key={i} onClick={()=>setTab(i)} style={{flex:1,padding:"9px 0",borderRadius:11,border:"none",background:tab===i?"linear-gradient(135deg,#1a1200,#2a1f00)":"transparent",color:tab===i?G.goldLt:G.sub,fontSize:10,fontWeight:700,cursor:"pointer",transition:"all .2s",boxShadow:tab===i?"0 2px 12px rgba(212,175,55,.15), inset 0 0 0 1px rgba(212,175,55,.2)":"none"}}>
              <div style={{fontSize:15,marginBottom:1}}>{t.icon}</div>
              <div style={{letterSpacing:.3}}>{t.l}</div>
            </button>
          ))}
        </div>

        {/* ══ SIGNAL ══ */}
        {tab===0&&<>
          {/* Price Card */}
          <div style={{background:"rgba(212,175,55,.03)",borderRadius:16,padding:"14px 16px",marginBottom:10,border:"1px solid rgba(212,175,55,.1)"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div>
                <div style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:4}}>Live Price</div>
                <div style={{fontSize:22,fontWeight:800,color:G.txt,letterSpacing:.5}}>{pair}</div>
                <div style={{display:"flex",alignItems:"center",gap:4,marginTop:4}}>
                  {actS.length>0?actS.map(s=><span key={s.name} style={{fontSize:9,color:G.gold,fontWeight:600,background:"rgba(212,175,55,.08)",padding:"1px 6px",borderRadius:4,border:"1px solid rgba(212,175,55,.15)"}}>{s.name}</span>):<span style={{fontSize:9,color:G.sub,fontWeight:600}}>Off-hours</span>}
                </div>
              </div>
              <div style={{textAlign:"right"}}>
                <div style={{fontSize:24,fontWeight:800,color:pCol,fontVariantNumeric:"tabular-nums",transition:"color .3s"}}>{price!=null?price.toFixed(isJPY?3:5):<span style={{color:G.sub}}>——</span>}</div>
                {pChg!=null&&pChg!==0&&<div style={{fontSize:10,fontWeight:700,color:pCol,marginTop:2}}>{pChg>0?"▲ +":"▼ "}{Math.abs(pChg).toFixed(isJPY?3:5)}</div>}
                {sig&&<div style={{display:"flex",alignItems:"center",gap:3,justifyContent:"flex-end",marginTop:3}}><div style={{width:5,height:5,borderRadius:"50%",background:volC[sig.vol]}}/><span style={{fontSize:9,fontWeight:700,color:volC[sig.vol]}}>{sig.vol} VOL</span></div>}
              </div>
            </div>
          </div>

          {/* Pair */}
          <div style={{background:"rgba(212,175,55,.03)",borderRadius:16,padding:"12px 14px",marginBottom:10,border:"1px solid rgba(212,175,55,.08)"}}>
            <div style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:8}}>Select Pair</div>
            <div style={{position:"relative",marginBottom:10}}>
              <input placeholder="Search pairs..." value={search} onChange={e=>setSearch(e.target.value)} style={{width:"100%",padding:"9px 12px 9px 32px",borderRadius:10,border:"1px solid rgba(212,175,55,.1)",background:"rgba(0,0,0,.3)",color:"#c8b87a",fontSize:12,outline:"none",boxSizing:"border-box"}}/>
              <span style={{position:"absolute",left:10,top:"50%",transform:"translateY(-50%)",fontSize:13,opacity:.4}}>🔍</span>
            </div>
            <div style={{display:"flex",flexWrap:"wrap",gap:5,maxHeight:96,overflowY:"auto"}}>
              {filtP.map(p=>(
                <button key={p} onClick={()=>{if(locked)return;setPair(p);setSig(null);setCd(null);setLocked(false);setSearch("");setNewsRisk(checkNews(p));}} style={{padding:"4px 10px",borderRadius:7,border:"1px solid",borderColor:pair===p?"rgba(212,175,55,.5)":"rgba(212,175,55,.08)",background:pair===p?"rgba(212,175,55,.12)":"rgba(0,0,0,.2)",color:pair===p?G.goldLt:G.sub,fontSize:11,fontWeight:600,cursor:locked?"not-allowed":"pointer",opacity:locked&&pair!==p?0.3:1,transition:"all .12s"}}>{p}</button>
              ))}
            </div>
          </div>

          {/* TF */}
          <div style={{background:"rgba(212,175,55,.03)",borderRadius:16,padding:"12px 14px",marginBottom:10,border:"1px solid rgba(212,175,55,.08)"}}>
            <div style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:8}}>Timeframe</div>
            <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
              {TFS.map(t=>(
                <button key={t} onClick={()=>{if(locked)return;setTf(t);setSig(null);setCd(null);setLocked(false);}} style={{padding:"7px 13px",borderRadius:9,border:"1px solid",borderColor:tf===t?"rgba(212,175,55,.4)":"rgba(212,175,55,.07)",background:tf===t?"rgba(212,175,55,.1)":"rgba(0,0,0,.2)",color:tf===t?G.goldLt:G.sub,fontSize:12,fontWeight:700,cursor:locked?"not-allowed":"pointer",opacity:locked&&tf!==t?0.3:1}}>{t}</button>
              ))}
            </div>
            {locked&&<div style={{fontSize:10,color:"#f59e0b",marginTop:7,fontWeight:600}}>🔒 Locked until candle closes</div>}
          </div>

          {/* W/L */}
          {(wins+losses)>0&&(
            <div style={{background:"rgba(212,175,55,.03)",borderRadius:14,padding:"10px 14px",marginBottom:10,border:"1px solid rgba(212,175,55,.08)",display:"flex",gap:14,alignItems:"center"}}>
              <div style={{textAlign:"center"}}><div style={{fontSize:20,fontWeight:800,color:G.green}}>{wins}</div><div style={{fontSize:8,color:G.sub,fontWeight:700,letterSpacing:1}}>WIN</div></div>
              <div style={{textAlign:"center"}}><div style={{fontSize:20,fontWeight:800,color:G.red}}>{losses}</div><div style={{fontSize:8,color:G.sub,fontWeight:700,letterSpacing:1}}>LOSS</div></div>
              <div style={{flex:1}}>
                <div style={{height:3,background:"rgba(212,175,55,.08)",borderRadius:99,overflow:"hidden",marginBottom:3}}>
                  <div style={{height:"100%",width:acc+"%",background:"linear-gradient(90deg,#d4af37,#f0c040)",borderRadius:99,transition:"width .5s"}}/>
                </div>
                <div style={{fontSize:9,color:G.sub,fontWeight:600}}>{acc}% accuracy • {total} signals</div>
              </div>
            </div>
          )}

          {/* Upcoming News */}
          {upcoming.length>0&&!newsRisk.risk&&(
            <div style={{background:"rgba(212,175,55,.03)",borderRadius:12,padding:"10px 13px",marginBottom:10,border:"1px solid rgba(212,175,55,.1)"}}>
              <div style={{fontSize:9,color:G.gold,fontWeight:700,letterSpacing:1.5,textTransform:"uppercase",marginBottom:7}}>📅 Upcoming News (PKT)</div>
              {upcoming.map((ev,i)=>(
                <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"4px 0",borderBottom:i<upcoming.length-1?"1px solid rgba(212,175,55,.06)":"none"}}>
                  <span style={{fontSize:10,color:G.sub,fontWeight:500}}>{ev.name}</span>
                  <span style={{fontSize:10,color:G.gold,fontWeight:700,background:"rgba(212,175,55,.08)",padding:"1px 7px",borderRadius:5}}>{ev.pkt}</span>
                </div>
              ))}
            </div>
          )}

          {/* Generate Button */}
          <button onClick={generate} disabled={blocked}
            style={{width:"100%",padding:"16px 0",borderRadius:14,border:newsRisk.risk?"1px solid rgba(239,68,68,.3)":blocked?"1px solid rgba(212,175,55,.08)":"1px solid rgba(212,175,55,.3)",
              background:newsRisk.risk?"rgba(239,68,68,.08)":blocked?"rgba(212,175,55,.04)":"linear-gradient(135deg,#1a1200 0%,#2d2000 50%,#1a1200 100%)",
              color:newsRisk.risk?"#fca5a5":blocked?G.sub:G.goldLt,
              fontSize:14,fontWeight:800,cursor:blocked?"not-allowed":"pointer",marginBottom:12,letterSpacing:2,
              boxShadow:blocked?"none":"0 0 30px rgba(212,175,55,.12), 0 4px 20px rgba(212,175,55,.08)",transition:"all .2s"}}>
            {newsRisk.risk?"🚫  NEWS — WAIT "+newsRisk.left+"min":loading?"⚙️  Analyzing...":locked?"🔒  "+fmt(cd):"⚡  GENERATE SIGNAL"}
          </button>

          {/* Signal Card */}
          {sig&&(
            <div key={sigKey} style={{background:sBg,border:"1px solid "+sBr,borderRadius:20,padding:"18px 16px",marginBottom:12,animation:"su .35s cubic-bezier(.16,1,.3,1)",boxShadow:"0 0 60px "+sCol+"15"}}>
              {/* Entry banner */}
              <div style={{background:"rgba("+( isCall?"34,197,94":"239,68,68")+",0.08)",border:"1px solid rgba("+(isCall?"34,197,94":"239,68,68")+",0.2)",borderRadius:10,padding:"8px 12px",marginBottom:14,display:"flex",alignItems:"center",gap:8}}>
                <div style={{width:6,height:6,borderRadius:"50%",background:eCol,boxShadow:"0 0 8px "+eCol}}/><span style={{fontSize:11,fontWeight:700,color:eCol}}>{eMsg}</span>
              </div>
              {/* Direction */}
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16}}>
                <div>
                  <div style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:5}}>Next Candle</div>
                  <div style={{fontSize:52,fontWeight:900,lineHeight:1,color:sCol,textShadow:"0 0 32px "+sCol+"40"}}>{isCall?"▲ CALL":"▼ PUT"}</div>
                  <div style={{display:"flex",gap:6,alignItems:"center",marginTop:7,flexWrap:"wrap"}}>
                    <span style={{fontSize:10,color:G.sub}}>{pair}</span><span style={{color:"rgba(255,255,255,.1)"}}>•</span>
                    <span style={{fontSize:10,color:G.sub}}>{tf}</span><span style={{color:"rgba(255,255,255,.1)"}}>•</span>
                    <span style={{fontSize:9,fontWeight:700,color:src==="REAL"?G.green:"#f59e0b",background:src==="REAL"?"rgba(34,197,94,.08)":"rgba(245,158,11,.08)",padding:"2px 7px",borderRadius:5,border:"1px solid "+(src==="REAL"?"rgba(34,197,94,.2)":"rgba(245,158,11,.2)")}}>{src==="REAL"?"✅ Real":"⚡ Smart"}</span>
                  </div>
                </div>
                {/* Ring */}
                <div style={{textAlign:"center",flexShrink:0}}>
                  <div style={{position:"relative",width:88,height:88}}>
                    <svg width="88" height="88" style={{transform:"rotate(-90deg)"}}>
                      <circle cx="44" cy="44" r="37" fill="none" stroke="rgba(212,175,55,.08)" strokeWidth="7"/>
                      <circle cx="44" cy="44" r="37" fill="none" stroke={sCol} strokeWidth="7" strokeDasharray={2*Math.PI*37} strokeDashoffset={2*Math.PI*37*(1-sig.confidence/100)} strokeLinecap="round" style={{transition:"stroke-dashoffset .8s cubic-bezier(.16,1,.3,1)",filter:"drop-shadow(0 0 6px "+sCol+")"}}/>
                    </svg>
                    <div style={{position:"absolute",inset:0,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"}}>
                      <div style={{fontSize:19,fontWeight:900,color:sCol,lineHeight:1}}>{sig.confidence}%</div>
                      <div style={{fontSize:8,color:G.sub,fontWeight:600,letterSpacing:.5,marginTop:1}}>CONF</div>
                    </div>
                  </div>
                  <div style={{fontSize:10,fontWeight:700,marginTop:4,color:sig.confidence>=85?G.gold:sig.confidence>=76?"#f59e0b":G.sub}}>{sig.strength}</div>
                </div>
              </div>
              {/* Bull/Bear bar */}
              <div style={{marginBottom:12}}>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:9,fontWeight:600,marginBottom:4}}>
                  <span style={{color:G.green}}>▲ BULL {sig.bull}</span><span style={{color:G.red}}>BEAR {sig.bear} ▼</span>
                </div>
                <div style={{height:4,background:"rgba(255,255,255,.04)",borderRadius:99,overflow:"hidden",display:"flex"}}>
                  <div style={{height:"100%",width:(sig.bull/(sig.bull+sig.bear)*100)+"%",background:"linear-gradient(90deg,#16a34a,#22c55e)",transition:"width .6s"}}/>
                  <div style={{height:"100%",flex:1,background:"linear-gradient(90deg,#dc2626,#ef4444)"}}/>
                </div>
              </div>
              {/* Tags */}
              <div style={{marginBottom:10}}>
                <div style={{fontSize:8,color:G.sub,fontWeight:600,letterSpacing:1.5,textTransform:"uppercase",marginBottom:6}}>Indicators</div>
                <div style={{display:"flex",flexWrap:"wrap",gap:4}}>
                  {sig.tags.map((t,i)=><span key={i} style={{padding:"3px 9px",borderRadius:20,background:t.includes("↑")?"rgba(34,197,94,.07)":"rgba(239,68,68,.07)",color:t.includes("↑")?G.green:G.red,fontSize:10,fontWeight:600,border:"1px solid "+(t.includes("↑")?"rgba(34,197,94,.18)":"rgba(239,68,68,.18)")}}>{t}</span>)}
                </div>
              </div>
              {/* Analysis */}
              {sig.reasons.length>0&&<><button onClick={()=>setShowR(r=>!r)} style={{background:"transparent",border:"none",color:G.sub,fontSize:10,cursor:"pointer",fontWeight:600,padding:"0 0 7px",letterSpacing:.3}}>{showR?"▲ Hide analysis":"▼ Show analysis"}</button>
              {showR&&<div style={{background:"rgba(0,0,0,.3)",borderRadius:10,padding:"10px 12px",marginBottom:8,border:"1px solid rgba(212,175,55,.06)"}}>{sig.reasons.map((r,i)=><div key={i} style={{fontSize:10,color:G.sub,padding:"3px 0",borderBottom:i<sig.reasons.length-1?"1px solid rgba(255,255,255,.03)":"none"}}>→ {r}</div>)}</div>}</>}
              {/* Countdown */}
              {cd!=null&&cd>0&&<div style={{background:"rgba(0,0,0,.3)",border:"1px solid rgba(212,175,55,.08)",borderRadius:12,padding:"10px 13px",marginBottom:10}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:5}}>
                  <span style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:1,textTransform:"uppercase"}}>Closes in</span>
                  <span style={{fontSize:22,fontWeight:800,color:G.txt,fontVariantNumeric:"tabular-nums"}}>{fmt(cd)}</span>
                </div>
                <div style={{height:3,background:"rgba(212,175,55,.06)",borderRadius:99,overflow:"hidden"}}>
                  <div style={{height:"100%",width:(cd/TF_SEC[tf]*100)+"%",background:"linear-gradient(90deg,"+sCol+","+sCol+"aa)",borderRadius:99,transition:"width 1s linear",boxShadow:"0 0 8px "+sCol}}/>
                </div>
              </div>}
              {expired&&!marked&&<div style={{background:"rgba(239,68,68,.06)",border:"1px solid rgba(239,68,68,.18)",borderRadius:10,padding:"9px 13px",marginBottom:10,textAlign:"center"}}><div style={{fontSize:12,fontWeight:700,color:"#fca5a5"}}>⏰ Candle closed — mark result</div></div>}
              {marked&&<div style={{background:"rgba(34,197,94,.06)",border:"1px solid rgba(34,197,94,.18)",borderRadius:10,padding:"9px 13px",marginBottom:10,textAlign:"center"}}><div style={{fontSize:12,fontWeight:700,color:"#4ade80"}}>✅ Result recorded</div></div>}
              {!marked&&<div style={{display:"flex",gap:8}}>
                <button onClick={()=>mark(true)} style={{flex:1,padding:"13px 0",borderRadius:12,border:"1px solid "+(expired?"rgba(34,197,94,.4)":"rgba(34,197,94,.15)"),background:expired?"rgba(34,197,94,.12)":"rgba(34,197,94,.05)",color:G.green,fontSize:13,fontWeight:800,cursor:"pointer",letterSpacing:.5}}>✅  WIN</button>
                <button onClick={()=>mark(false)} style={{flex:1,padding:"13px 0",borderRadius:12,border:"1px solid "+(expired?"rgba(239,68,68,.4)":"rgba(239,68,68,.15)"),background:expired?"rgba(239,68,68,.12)":"rgba(239,68,68,.05)",color:G.red,fontSize:13,fontWeight:800,cursor:"pointer",letterSpacing:.5}}>❌  LOSS</button>
              </div>}
            </div>
          )}
        </>}

        {/* ══ SCANNER ══ */}
        {tab===1&&<div>
          <div style={{background:"rgba(212,175,55,.03)",borderRadius:16,padding:"14px",marginBottom:12,border:"1px solid rgba(212,175,55,.1)"}}>
            <div style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:4}}>Multi-Pair Scanner</div>
            <div style={{fontSize:11,color:G.sub,marginBottom:12,lineHeight:1.5}}>Scans top 10 pairs • ~10 requests</div>
            <div style={{display:"flex",gap:5,marginBottom:12,flexWrap:"wrap"}}>
              {TFS.map(t=><button key={t} onClick={()=>setTf(t)} style={{padding:"6px 12px",borderRadius:8,border:"1px solid",borderColor:tf===t?"rgba(212,175,55,.4)":"rgba(212,175,55,.07)",background:tf===t?"rgba(212,175,55,.1)":"rgba(0,0,0,.2)",color:tf===t?G.goldLt:G.sub,fontSize:11,fontWeight:700,cursor:"pointer"}}>{t}</button>)}
            </div>
            <button onClick={doScan} disabled={scanning} style={{width:"100%",padding:"14px 0",borderRadius:12,border:"1px solid "+(scanning?"rgba(212,175,55,.06)":"rgba(212,175,55,.25)"),background:scanning?"rgba(212,175,55,.03)":"linear-gradient(135deg,#1a1200,#2d2000)",color:scanning?G.sub:G.goldLt,fontSize:13,fontWeight:800,cursor:scanning?"not-allowed":"pointer",letterSpacing:1.5,boxShadow:scanning?"none":"0 4px 20px rgba(212,175,55,.08)"}}>
              {scanning?"⚙️  Scanning...":"🔍  SCAN ALL PAIRS"}
            </button>
          </div>
          {scanRes.length>0&&<div>
            <div style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:10}}>Best signals first</div>
            {scanRes.map((r,i)=>(
              <button key={r.pair} onClick={()=>{setPair(r.pair);setTab(0);setSig(null);setCd(null);setLocked(false);}} style={{width:"100%",background:i===0?"rgba(212,175,55,.05)":"rgba(0,0,0,.2)",border:"1px solid "+(i===0?"rgba(212,175,55,.2)":"rgba(212,175,55,.07)"),borderRadius:14,padding:"12px 14px",marginBottom:8,display:"flex",alignItems:"center",justifyContent:"space-between",cursor:"pointer",textAlign:"left"}}>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <div style={{width:24,height:24,borderRadius:7,background:i===0?"rgba(212,175,55,.15)":"rgba(255,255,255,.04)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,color:i===0?G.gold:G.sub}}>#{i+1}</div>
                  <div><div style={{fontSize:13,fontWeight:800,color:G.txt}}>{r.pair}</div><div style={{fontSize:9,color:G.sub,marginTop:1}}>{r.strength} • {r.vol} Vol</div></div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:10}}>
                  <div style={{fontSize:18,fontWeight:900,color:r.direction==="CALL"?G.green:G.red}}>{r.direction==="CALL"?"▲":"▼"} {r.direction}</div>
                  <div style={{textAlign:"center",background:"rgba(212,175,55,.06)",padding:"4px 8px",borderRadius:8,border:"1px solid rgba(212,175,55,.12)"}}>
                    <div style={{fontSize:15,fontWeight:900,color:r.confidence>=80?G.gold:G.sub}}>{r.confidence}%</div>
                    <div style={{fontSize:8,color:G.sub,fontWeight:600}}>CONF</div>
                  </div>
                </div>
              </button>
            ))}
            <div style={{fontSize:10,color:G.sub,textAlign:"center",marginTop:4}}>Tap pair to open Signal tab</div>
          </div>}
        </div>}

        {/* ══ HISTORY ══ */}
        {tab===2&&<div>
          {history.length===0?(
            <div style={{background:"rgba(212,175,55,.02)",borderRadius:16,padding:"40px 16px",border:"1px solid rgba(212,175,55,.07)",textAlign:"center"}}>
              <div style={{fontSize:36,marginBottom:12}}>📋</div>
              <div style={{fontSize:14,color:G.sub,fontWeight:600}}>No signals yet</div>
            </div>
          ):(
            <>
              <div style={{display:"flex",gap:8,marginBottom:12}}>
                {[[wins,G.green,"WIN"],[losses,G.red,"LOSS"],[(acc||0)+"%",G.gold,"ACC"]].map(([v,c,l])=>(
                  <div key={l} style={{flex:1,background:"rgba(212,175,55,.03)",borderRadius:12,padding:"12px 8px",border:"1px solid rgba(212,175,55,.1)",textAlign:"center"}}>
                    <div style={{fontSize:20,fontWeight:900,color:c}}>{v}</div>
                    <div style={{fontSize:8,color:G.sub,fontWeight:700,letterSpacing:1,marginTop:2}}>{l}</div>
                  </div>
                ))}
              </div>
              {history.map(s=>(
                <div key={s.id} style={{background:"rgba(212,175,55,.02)",borderRadius:12,padding:"11px 14px",marginBottom:7,border:"1px solid rgba(212,175,55,.07)",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                  <div>
                    <div style={{fontSize:13,fontWeight:700,color:G.txt}}>{s.pair} <span style={{color:G.sub,fontWeight:400}}>•</span> {s.tf}</div>
                    <div style={{fontSize:9,color:G.sub,marginTop:2}}>{s.time} • {s.str}</div>
                  </div>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <div style={{fontSize:13,fontWeight:800,color:s.dir==="CALL"?G.green:G.red}}>{s.dir==="CALL"?"▲":"▼"} {s.dir}</div>
                    <div style={{fontSize:11,fontWeight:700,color:G.sub}}>{s.conf}%</div>
                    {s.res?<div style={{fontSize:10,fontWeight:800,color:s.res==="WIN"?G.green:G.red,background:s.res==="WIN"?"rgba(34,197,94,.08)":"rgba(239,68,68,.08)",padding:"2px 8px",borderRadius:6,border:"1px solid "+(s.res==="WIN"?"rgba(34,197,94,.2)":"rgba(239,68,68,.2)")}}>{s.res}</div>:<div style={{fontSize:9,color:G.sub,fontWeight:600,background:"rgba(212,175,55,.04)",padding:"2px 7px",borderRadius:5}}>PENDING</div>}
                  </div>
                </div>
              ))}
            </>
          )}
        </div>}

        {/* ══ RISK ══ */}
        {tab===3&&<div>
          <div style={{background:"rgba(212,175,55,.03)",borderRadius:16,padding:"14px",marginBottom:12,border:"1px solid rgba(212,175,55,.1)"}}>
            <div style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:12}}>💰 Risk Calculator</div>
            {[["Account Balance ($)",bal,setBal],["Risk Per Trade (%)",rp,setRp],["Broker Payout (%)",pay,setPay]].map(([l,v,s])=>(
              <div key={l} style={{marginBottom:10}}>
                <div style={{fontSize:9,color:G.sub,fontWeight:600,marginBottom:5,textTransform:"uppercase",letterSpacing:.5}}>{l}</div>
                <input type="number" value={v} onChange={e=>s(e.target.value)} style={{width:"100%",padding:"10px 13px",borderRadius:10,border:"1px solid rgba(212,175,55,.12)",background:"rgba(0,0,0,.3)",color:G.txt,fontSize:16,fontWeight:700,outline:"none",boxSizing:"border-box"}}/>
              </div>
            ))}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginTop:4}}>
              {[["Trade Amount","$"+rc.amt,G.gold],["Potential Profit","$"+rc.profit,G.green],["Max Daily Loss","$"+rc.maxLoss,G.red],["Max Trades/Day",rc.maxTrades,"#f59e0b"]].map(([l,v,c])=>(
                <div key={l} style={{background:"rgba(212,175,55,.03)",borderRadius:10,padding:"10px 12px",border:"1px solid rgba(212,175,55,.08)"}}>
                  <div style={{fontSize:8,color:G.sub,fontWeight:600,textTransform:"uppercase",letterSpacing:.4,marginBottom:3}}>{l}</div>
                  <div style={{fontSize:18,fontWeight:800,color:c}}>{v}</div>
                </div>
              ))}
            </div>
          </div>
          <div style={{background:"rgba(212,175,55,.03)",borderRadius:16,padding:"14px",marginBottom:12,border:"1px solid rgba(212,175,55,.1)"}}>
            <div style={{fontSize:9,color:G.sub,fontWeight:600,letterSpacing:2,textTransform:"uppercase",marginBottom:12}}>🧮 Martingale Calculator</div>
            {[["Base Stake ($)",mb,setMb],["Payout (%)",pay,setPay]].map(([l,v,s])=>(
              <div key={l} style={{marginBottom:10}}>
                <div style={{fontSize:9,color:G.sub,fontWeight:600,marginBottom:5,textTransform:"uppercase",letterSpacing:.5}}>{l}</div>
                <input type="number" value={v} onChange={e=>s(e.target.value)} style={{width:"100%",padding:"10px 13px",borderRadius:10,border:"1px solid rgba(212,175,55,.12)",background:"rgba(0,0,0,.3)",color:G.txt,fontSize:16,fontWeight:700,outline:"none",boxSizing:"border-box"}}/>
              </div>
            ))}
            <div style={{borderRadius:10,overflow:"hidden",border:"1px solid rgba(212,175,55,.1)"}}>
              <div style={{display:"grid",gridTemplateColumns:".4fr 1fr 1fr 1fr",background:"rgba(0,0,0,.3)",padding:"8px 12px"}}>
                {["#","Stake","Profit","Risk"].map(h=><div key={h} style={{fontSize:8,fontWeight:700,color:G.sub,textTransform:"uppercase",letterSpacing:.8}}>{h}</div>)}
              </div>
              {getMart(parseFloat(mb)||1,parseFloat(pay)||80).map((r,i)=>(
                <div key={i} style={{display:"grid",gridTemplateColumns:".4fr 1fr 1fr 1fr",padding:"9px 12px",background:i%2===0?"rgba(212,175,55,.02)":"rgba(0,0,0,.15)",borderTop:"1px solid rgba(212,175,55,.06)"}}>
                  <div style={{fontSize:11,fontWeight:700,color:i===0?G.gold:G.sub}}>#{r.step}</div>
                  <div style={{fontSize:11,fontWeight:700,color:G.txt}}>${r.stake}</div>
                  <div style={{fontSize:11,fontWeight:700,color:G.green}}>+${r.profit}</div>
                  <div style={{fontSize:11,fontWeight:700,color:G.red}}>${r.risk}</div>
                </div>
              ))}
            </div>
            <p style={{marginTop:10,fontSize:10,color:G.sub,lineHeight:1.6}}>⚠️ Martingale compounds losses. Use strict stop-loss.</p>
          </div>
        </div>}

        <div style={{background:"rgba(212,175,55,.02)",border:"1px solid rgba(212,175,55,.06)",borderRadius:10,padding:"9px 12px",fontSize:9,color:G.sub,lineHeight:1.8,marginTop:4}}>
          ⚠️ Binary options involve risk. Signals are analysis only — not financial advice.
        </div>
      </div>

      <style>{`
        @keyframes lv{0%,100%{opacity:1}50%{opacity:.3}}
        @keyframes su{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
        @keyframes spin{to{transform:rotate(360deg)}}
        @keyframes goldPulse{0%,100%{box-shadow:0 0 0 0 rgba(212,175,55,.4)}70%{box-shadow:0 0 0 6px rgba(212,175,55,0)}}
        button:active{transform:scale(.95)!important}
        input::placeholder{color:#3a2e1a}
        *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
        ::-webkit-scrollbar{width:2px;height:2px}
        ::-webkit-scrollbar-track{background:transparent}
        ::-webkit-scrollbar-thumb{background:rgba(212,175,55,.15);border-radius:2px}
      `}</style>
    </div>
  );
}

export default function App(){
  const[open,setOpen]=useState(false);
  if(!open)return <Pin onUnlock={()=>setOpen(true)}/>;
  return <Board/>;
}
